using System;
using System.Collections.Generic;

public class Dialogue {

    private int id;
    private int type;
    private string title;
    private string[] content;
    private List<Dialogue> options;

    public Dialogue(int id, int type, string title, string[] content) {
        
    }

}